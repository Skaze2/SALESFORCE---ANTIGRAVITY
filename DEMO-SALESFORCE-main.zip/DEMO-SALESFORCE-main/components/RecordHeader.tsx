import React from 'react';
import { Plus, ChevronDown } from 'lucide-react';
import { ProspectData } from '../App';

interface RecordHeaderProps {
    data: ProspectData;
    onNewTaskClick?: () => void;
}

export const RecordHeader: React.FC<RecordHeaderProps> = ({ data, onNewTaskClick }) => {
  return (
    <div className="bg-gray-50 rounded-t pt-4 px-6 pb-2 border-b border-gray-200">
      {/* Top Row: Icon, Title, Actions */}
      <div className="flex justify-between items-start mb-4">
        <div className="flex gap-3">
            {/* Icon */}
            <div className="w-10 h-10 bg-[#7f8de1] rounded flex items-center justify-center shadow-sm">
                <svg className="w-6 h-6 text-white fill-current" viewBox="0 0 20 20"><path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" /></svg>
            </div>
            {/* Title Info */}
            <div>
                <div className="text-xs text-gray-500">Cuenta personal</div>
                <h1 className="text-xl font-bold text-gray-800 leading-tight">
                    {data.firstName} {data.lastName}
                </h1>
            </div>
        </div>

        {/* Buttons */}
        <div className="flex gap-2">
            <button className="flex items-center gap-1 px-4 py-1.5 bg-white border border-gray-300 rounded text-blue-600 font-medium hover:bg-gray-50 text-sm shadow-sm">
                <Plus size={16} /> Seguir
            </button>
            <button 
                onClick={onNewTaskClick}
                className="px-4 py-1.5 bg-white border border-gray-300 rounded text-blue-600 font-medium hover:bg-gray-50 text-sm shadow-sm"
            >
                Nueva tarea
            </button>
        </div>
      </div>

      {/* Highlights Field Row */}
      <div className="flex gap-12 mt-4 mb-2 overflow-x-auto">
        <div className="flex flex-col">
            <span className="text-[11px] text-gray-500">País</span>
            <span className="text-sm text-gray-800">{data.country || 'No especificado'}</span>
        </div>
        <div className="flex flex-col">
            <span className="text-[11px] text-gray-500">Programa de interés</span>
            <span className="text-sm text-gray-800">{data.program || 'N/A'}</span>
        </div>
        <div className="flex flex-col">
            <span className="text-[11px] text-gray-500">Base de ofertas</span>
            <div className="mt-1 w-4 h-4 bg-blue-500 rounded-sm"></div>
        </div>
        <div className="flex flex-col">
            <span className="text-[11px] text-gray-500">Días de creación</span>
            <span className="text-sm text-gray-800">{data.daysCreation}</span>
        </div>
        <div className="flex flex-col">
            <span className="text-[11px] text-gray-500">Tipo de registro de cuenta</span>
            <span className="text-sm text-gray-800">Lead Account</span>
        </div>
      </div>
    </div>
  );
};