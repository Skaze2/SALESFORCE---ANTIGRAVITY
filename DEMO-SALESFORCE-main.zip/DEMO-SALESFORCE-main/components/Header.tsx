import React, { useState, useEffect, useRef } from 'react';
import { Search, Bell, Plus, Star, ChevronDown, HelpCircle, Mountain, Book } from 'lucide-react';
import { db } from '../firebaseConfig';
import { ProspectData } from '../App';

interface HeaderProps {
    onOpenRecord: (record: ProspectData) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenRecord }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<ProspectData[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [allProspects, setAllProspects] = useState<ProspectData[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Fetch all prospects on mount (efficient for demo size)
  useEffect(() => {
    const prospectsRef = db.ref('prospects');
    prospectsRef.on('value', (snapshot) => {
        const data = snapshot.val();
        if (data) {
            const list: ProspectData[] = Object.keys(data).map(key => ({
                id: key,
                ...data[key]
            }));
            setAllProspects(list);
        }
    });

    return () => prospectsRef.off();
  }, []);

  // Filter Logic
  useEffect(() => {
      if (searchTerm.trim() === '') {
          setResults([]);
          return;
      }

      const lowerTerm = searchTerm.toLowerCase();
      const filtered = allProspects.filter(p => {
          const fullName = `${p.firstName} ${p.lastName}`.toLowerCase();
          const email = p.email.toLowerCase();
          const fullPhone = `${p.phoneCode}${p.phone}`.replace(/\s/g, '');
          
          return fullName.includes(lowerTerm) || 
                 email.includes(lowerTerm) || 
                 fullPhone.includes(lowerTerm) ||
                 p.phone.includes(lowerTerm);
      });
      
      setResults(filtered);
  }, [searchTerm, allProspects]);

  // Click Outside Logic
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
            setShowDropdown(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (record: ProspectData) => {
      onOpenRecord(record);
      setShowDropdown(false);
      setSearchTerm('');
  };

  return (
    <header className="h-[50px] bg-white border-b border-gray-200 flex items-center px-4 justify-between shrink-0 z-50">
      {/* Left: Logo */}
      <div className="flex items-center gap-4 w-64">
        <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-yellow-400 rounded flex items-center justify-center text-white font-bold text-xs shadow-sm">
                <span className="text-black text-lg">🐝</span>
            </div>
            <span className="font-semibold text-lg text-gray-700 tracking-tight">smartBeemo<span className="text-xs align-top">™</span></span>
        </div>
      </div>

      {/* Center: Global Search */}
      <div className="flex-1 max-w-2xl px-4 relative" ref={dropdownRef}>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={16} className="text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-1.5 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 sm:text-sm shadow-sm transition-shadow"
            placeholder="Buscar..."
            value={searchTerm}
            onChange={(e) => {
                setSearchTerm(e.target.value);
                setShowDropdown(true);
            }}
            onFocus={() => setShowDropdown(true)}
          />
        </div>

        {/* Search Results Dropdown */}
        {showDropdown && searchTerm && (
            <div className="absolute top-full left-4 right-4 bg-white border border-gray-200 rounded-b-md shadow-lg mt-1 max-h-80 overflow-y-auto z-[60]">
                {results.length > 0 ? (
                    <ul>
                        <li className="px-4 py-2 text-xs font-bold text-gray-500 bg-gray-50 uppercase border-b border-gray-100">
                            Resultados ({results.length})
                        </li>
                        {results.map((prospect) => (
                            <li 
                                key={prospect.id} 
                                onClick={() => handleSelect(prospect)}
                                className="px-4 py-3 hover:bg-gray-100 cursor-pointer border-b border-gray-50 flex items-center gap-3 transition-colors group"
                            >
                                <div className="w-8 h-8 bg-[#7f8de1] rounded-[4px] flex items-center justify-center shrink-0">
                                    <Book size={16} className="text-white" />
                                </div>
                                <div className="flex flex-col">
                                    <span className="text-sm text-blue-600 font-medium group-hover:underline">
                                        {prospect.firstName} {prospect.lastName}
                                    </span>
                                    <span className="text-xs text-gray-500">
                                        {prospect.program} • {prospect.email}
                                    </span>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <div className="px-4 py-3 text-sm text-gray-500 text-center">
                        No se encontraron resultados
                    </div>
                )}
            </div>
        )}
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2 sm:gap-4 text-gray-500">
        
        {/* Favorites Split Button */}
        <div className="flex items-center h-8 bg-white border border-gray-300 rounded overflow-hidden shadow-sm">
            <button className="px-2 h-full hover:bg-gray-100 flex items-center justify-center border-r border-gray-300 text-gray-500">
                <Star size={18} />
            </button>
            <button className="px-1 h-full hover:bg-gray-100 flex items-center justify-center text-gray-500">
                <ChevronDown size={12} />
            </button>
        </div>

        {/* Global Actions (Plus) */}
        <button className="w-8 h-8 bg-[#747474] hover:bg-[#5c5c5c] rounded-[4px] text-white flex items-center justify-center shadow-sm transition-colors">
            <Plus size={22} strokeWidth={2.5} />
        </button>

        {/* Trailhead Icon */}
        <button className="w-8 h-8 hover:bg-gray-100 rounded text-gray-500 flex items-center justify-center">
             <Mountain size={22} strokeWidth={1.5} />
        </button>

        {/* Help */}
        <button className="w-8 h-8 hover:bg-gray-100 rounded text-gray-500 flex items-center justify-center">
            <HelpCircle size={22} strokeWidth={1.5} />
        </button>

         {/* Setup (Gear + Lightning) */}
        <button className="w-8 h-8 hover:bg-gray-100 rounded text-gray-500 flex items-center justify-center relative">
             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                 <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.47a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
             </svg>
             <div className="absolute inset-0 flex items-center justify-center">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2">
                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                </svg>
             </div>
        </button>

        {/* Bell */}
        <button className="w-8 h-8 hover:bg-gray-100 rounded text-gray-500 flex items-center justify-center relative">
            <Bell size={22} strokeWidth={1.5} />
             <div className="absolute top-2 right-2 w-2 h-2 bg-[#c23934] rounded-full border border-white"></div>
        </button>
        
        {/* User Profile */}
        <div className="relative ml-2 mr-1">
           <div className="w-10 h-10 rounded-full bg-white border-2 border-white shadow-sm overflow-hidden relative cursor-pointer">
                <img 
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                    alt="User Profile" 
                    className="w-full h-full object-cover"
                />
           </div>
           {/* Rank Badge */}
           <div className="absolute -bottom-1.5 left-1/2 transform -translate-x-1/2 bg-[#ffb75d] text-[#4f360e] text-[9px] font-bold px-2 rounded-full border border-white shadow-sm whitespace-nowrap leading-3">
               RANGER
           </div>
        </div>

      </div>
    </header>
  );
};