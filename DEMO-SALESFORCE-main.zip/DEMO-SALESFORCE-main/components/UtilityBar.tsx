import React, { useState } from 'react';
import { Phone, Clock, FileText, Zap, List, UserPlus, MessageSquare, CheckSquare } from 'lucide-react';
import { ReferidoPanel } from './ReferidoPanel';

const UtilityItem = ({ icon: Icon, label, onClick, isActive, className }: { icon: any, label: string, onClick?: () => void, isActive?: boolean, className?: string }) => (
    <button 
        onClick={onClick}
        className={`flex items-center gap-2 px-3 h-full transition-colors font-medium text-xs border-r border-transparent ${isActive ? 'bg-white text-blue-600 border-l border-r-gray-200 border-l-gray-200 shadow-[0_-2px_0_0_#0070d2_inset]' : 'text-gray-700 hover:bg-black/10'} ${className}`}
    >
        <Icon size={16} />
        <span>{label}</span>
    </button>
);

export const UtilityBar: React.FC = () => {
  const [isReferidoOpen, setIsReferidoOpen] = useState(false);

  return (
    <div className="h-[35px] bg-[#f3f3f3] border-t border-gray-300 flex items-center px-2 shrink-0 justify-start fixed bottom-0 w-full z-50 shadow-[0_-2px_4px_rgba(0,0,0,0.05)]">
        <UtilityItem icon={Phone} label="Five9" />
        <UtilityItem icon={Clock} label="History" />
        <UtilityItem icon={FileText} label="Notes" />
        <UtilityItem icon={Zap} label="List View" />
        <UtilityItem icon={List} label="Omni-Channel" />
        <UtilityItem icon={CheckSquare} label="To Do List" />
        <UtilityItem icon={MessageSquare} label="whatsapp" />
        
        {/* Referido Item Container (Relative for positioning panel) */}
        <div className="relative h-full">
            <UtilityItem 
                icon={UserPlus} 
                label="Referido" 
                onClick={() => setIsReferidoOpen(!isReferidoOpen)} 
                isActive={isReferidoOpen}
            />
            {isReferidoOpen && (
                <ReferidoPanel onClose={() => setIsReferidoOpen(false)} />
            )}
        </div>
    </div>
  );
};